import Enquiry from "./enquiry.model.js";

/* =========================================
   ➕ CREATE ENQUIRY
========================================= */
export const createEnquiry = async (req, res) => {
  try {
    const { name, contact, address, course } = req.body;
    const { libraryId } = req.user;

    if (!name || !contact || !address || !course) {
      return res.status(400).json({
        message: "Please fill all required fields"
      });
    }

    const enquiry = await Enquiry.create({
      name,
      contact,
      address,
      course,
      libraryId
    });

    res.status(201).json({
      message: "Enquiry added successfully",
      enquiry
    });

  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
};

/* =========================================
   📋 GET ALL ENQUIRIES (Pagination + Search)
========================================= */
export const getAllEnquiries = async (req, res) => {
  try {

    const { libraryId } = req.user;

    const {
      page = 1,
      limit = 10,
      search = "",
      date
    } = req.query;

    const query = {
      libraryId
    };

    // 🔍 SEARCH FILTER
    if (search) {

      query.$or = [
        {
          name: {
            $regex: search,
            $options: "i"
          }
        },
        {
          contact: {
            $regex: search,
            $options: "i"
          }
        }
      ];
    }

    // 📅 DATE FILTER
    if (date) {

      const start = new Date(date);
      start.setHours(0, 0, 0, 0);

      const end = new Date(date);
      end.setHours(23, 59, 59, 999);

      query.createdAt = {
        $gte: start,
        $lte: end
      };
    }

    const pageNumber = Math.max(1, Number.parseInt(page, 10) || 1);
    const pageLimit = Math.max(1, Number.parseInt(limit, 10) || 10);

    const enquiries = await Enquiry.find(query)
      // Keep CSV/manual import order (oldest first). `_id` makes the order
      // deterministic when multiple enquiries share the same createdAt value.
      .sort({ createdAt: 1, _id: 1 })
      .skip((pageNumber - 1) * pageLimit)
      .limit(pageLimit);

    const total = await Enquiry.countDocuments(query);

    res.json({
      total,
      page: pageNumber,
      pages: Math.ceil(total / pageLimit),
      enquiries
    });

  } catch (error) {

    res.status(500).json({
      message: error.message
    });

  }
};

/* =========================================
   🔍 GET SINGLE ENQUIRY
========================================= */
export const getSingleEnquiry = async (req, res) => {
  try {
    const { id } = req.params;
    const { libraryId } = req.user;

    const enquiry = await Enquiry.findOne({
      _id: id,
      libraryId
    });

    if (!enquiry) {
      return res.status(404).json({
        message: "Enquiry not found"
      });
    }

    res.json(enquiry);

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/* =========================================
   ✏️ UPDATE ENQUIRY
========================================= */
export const updateEnquiry = async (req, res) => {
  try {
    const { id } = req.params;
    const { libraryId } = req.user;

    const enquiry = await Enquiry.findOneAndUpdate(
      { _id: id, libraryId },
      req.body,
      { new: true }
    );

    if (!enquiry) {
      return res.status(404).json({
        message: "Enquiry not found"
      });
    }

    res.json({
      message: "Enquiry updated successfully",
      enquiry
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/* =========================================
   ❌ DELETE ENQUIRY
========================================= */
export const deleteEnquiry = async (req, res) => {
  try {
    const { id } = req.params;
    const { libraryId } = req.user;

    const enquiry = await Enquiry.findOneAndDelete({
      _id: id,
      libraryId
    });

    if (!enquiry) {
      return res.status(404).json({
        message: "Enquiry not found"
      });
    }

    res.json({
      message: "Enquiry deleted successfully"
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/* =========================================
   🌐 WEBSITE ENQUIRY (PUBLIC)
========================================= */
export const createWebsiteEnquiry = async (req, res) => {
  try {

    const { name, contact, address, course, libraryId } = req.body;

    if (!name || !contact || !address || !course || !libraryId) {
      return res.status(400).json({
        message: "Please fill all required fields"
      });
    }

    const enquiry = await Enquiry.create({
      name,
      contact,
      address,
      course,
      libraryId,
      source: "website"
    });

    res.status(201).json({
      message: "Enquiry submitted successfully",
      enquiry
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/* =========================================
   📅 SET DEMO DATE
========================================= */
export const setDemoDate = async (req, res) => {
  try {

    const { id } = req.params;
    const { libraryId } = req.user;

    const enquiry = await Enquiry.findOneAndUpdate(
      { _id: id, libraryId },
      { demoDate: new Date() },
      { new: true }
    );

    if (!enquiry) {
      return res.status(404).json({
        message: "Enquiry not found"
      });
    }

    res.json({
      message: "Demo date saved",
      enquiry
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/* =========================================
   📝 ADD REMARK
========================================= */
export const addRemark = async (req, res) => {
  try {

    const { id } = req.params;
    const { libraryId } = req.user;
    const { remark } = req.body;

    const enquiry = await Enquiry.findOneAndUpdate(
      { _id: id, libraryId },
      { remark },
      { new: true }
    );

    if (!enquiry) {
      return res.status(404).json({
        message: "Enquiry not found"
      });
    }

    res.json({
      message: "Remark added",
      enquiry
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
