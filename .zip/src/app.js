import express from "express";
import cors from "cors";
import routes from "./routes/index.js";

const app = express();

app.use(cors()); // enable CORS

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static("uploads"));

app.use("/api/v1/", routes);

export default app;